package com.android.capstone.sereluna.data.model

data class Chat (
    val message: String,
    val senderId: String,
    val isBot: Boolean

)