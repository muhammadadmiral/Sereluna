// ChatbotActivity.kt
package com.android.capstone.sereluna.ui.diary

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.capstone.sereluna.data.adapter.ChatAdapter
import com.android.capstone.sereluna.data.api.ChatRequest
import com.android.capstone.sereluna.data.api.ChatResponse
import com.android.capstone.sereluna.data.api.ChatbotApiService
import com.android.capstone.sereluna.data.model.Chat
import com.android.capstone.sereluna.databinding.ActivityChatbotBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChatbotActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatbotBinding
    private val chatbotApiService = ChatbotApiService.create()
    private val chatList = mutableListOf<Chat>()
    private lateinit var chatAdapter: ChatAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatbotBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup RecyclerView
        chatAdapter = ChatAdapter(chatList)
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@ChatbotActivity)
            adapter = chatAdapter
        }

        binding.backButton.setOnClickListener {
            finish() // Kembali ke aktivitas sebelumnya
        }

        binding.submitFab.setOnClickListener {
            val userMessage = binding.diaryEditText.text.toString()
            if (userMessage.isNotBlank()) {
                sendMessageToBackend(userMessage)
                binding.diaryEditText.text.clear()
            } else {
                Toast.makeText(this, "Please enter a message", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendMessageToBackend(message: String) {
        val request = ChatRequest(message)
        Log.d("ChatbotActivity", "Sending message to backend: $message")

        // Tampilkan pesan pengguna di RecyclerView
        addMessageToChatList(Chat(message, "user", isBot = false))

        chatbotApiService.sendMessage(request).enqueue(object : Callback<ChatResponse> {
            override fun onResponse(call: Call<ChatResponse>, response: Response<ChatResponse>) {
                if (response.isSuccessful) {
                    val botReply = response.body()?.journal?.suggestion ?: "No response from bot"
                    displayMessage(botReply)
                    saveDiaryToFirestore(message, botReply) // Simpan entri dan respons ke Firestore
                } else {
                    val errorMessage = response.errorBody()?.string() ?: "Unknown error"
                    Log.e("ChatbotActivity", "Failed to get response: $errorMessage")
                    displayMessage("Failed to get response: $errorMessage")
                }
            }

            override fun onFailure(call: Call<ChatResponse>, t: Throwable) {
                val error = "Error occurred: ${t.message}"
                Log.e("ChatbotActivity", error, t)
                displayMessage(error)
            }
        })
    }

    private fun addMessageToChatList(chat: Chat) {
        chatList.add(chat)
        chatAdapter.notifyItemInserted(chatList.size - 1)
        binding.recyclerView.scrollToPosition(chatList.size - 1)
    }

    private fun displayMessage(message: String) {
        addMessageToChatList(Chat(message, "bot", isBot = true))
    }

    private fun saveDiaryToFirestore(userMessage: String, botReply: String) {
        // Implementasikan logika penyimpanan ke Firestore di sini.
    }
}
