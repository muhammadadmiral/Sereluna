package com.android.capstone.sereluna.ui.diary

import androidx.appcompat.app.AppCompatActivity

class ChatbotActivity:AppCompatActivity() {

}