package com.android.capstone.sereluna.data.model

data class Diary (
    val id:String,
    val date: String,
    val content: String,


)