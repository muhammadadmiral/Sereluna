package com.android.capstone.sereluna.ui.profile

import android.content.Intent
import com.android.capstone.sereluna.utils.loadImage
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.android.capstone.sereluna.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load and display user profile data
        val sharedPreferences = getSharedPreferences("user_profile", MODE_PRIVATE)
        binding.nameEditText.setText(sharedPreferences.getString("name", ""))
        binding.emailEditText.setText(sharedPreferences.getString("email", ""))
        binding.profileImageView.loadImage(sharedPreferences.getString("photoUrl", ""))

        binding.changePhotoButton.setOnClickListener {
            // Implementasikan intent untuk memilih foto dari galeri
        }

        binding.saveButton.setOnClickListener {
            val name = binding.nameEditText.text.toString()
            val email = binding.emailEditText.text.toString()
            // Simpan data profil ke SharedPreferences atau sumber data lainnya
            sharedPreferences.edit().apply {
                putString("name", name)
                putString("email", email)
                // ... (simpan data foto profil jika ada perubahan)
                apply()
            }
            finish()
        }
    }
}
